
# Hack, WordPress – A quick introduction to diagnose, restore and protect a hacked WordPress
=============================================


## Installation
---------------------
Like so many people, as a present for the end of the year 2017, on of my site on Wordpress have been hacked

1. htaccess_for_wp_admin.txt => this one of for the /wp-admin/. Be sure to rename as .htaccess

2. htaccess_for_wp_root_dir.txt => this directory of your wp installation. Be sure to rename as .htaccess


## Usage
--------------
This is a personal memo to archive some the best practises that I have found on the web. Unfortunately, I did not apply these measures before my site was hacked, what a schmock! Never late to learn :)

So, it also reminds me this quote that I have heard recently:
"Give a man a fish and you feed him for a day, teach a man to fish and you feed him for a lifetime."


I heard it from Mikhail Gorbachev. I do not believe this is Maïmonide. I do believe this is Confucius.



## For more information
------------------------------------
Feel free to check in english some articles @
[Flaven.net](http://flaven.fr//)








