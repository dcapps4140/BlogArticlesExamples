## 001_nlp_spacy_python_realp

A bunch of scripts extracted from an excellent article "Natural Language Processing With spaCy in Python"

### Source
Natural Language Processing With spaCy in Python :: [https://realpython.com/natural-language-processing-spacy-python/](https://realpython.com/natural-language-processing-spacy-python/)

