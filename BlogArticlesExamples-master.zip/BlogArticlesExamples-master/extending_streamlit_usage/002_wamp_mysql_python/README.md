### 002_wamp_mysql_python

Some experiments with WP hosted locally with XAMP and Spacy retrieving Posts from the WP MySQL database.

## Source
- Streamlit  :: [https://streamlit.io/](https://streamlit.io/)

- Streamlit Gallery :: [https://streamlit.io/gallery](https://streamlit.io/gallery)

- Streamlit Docs :: [https://docs.streamlit.io/en/stable/](https://docs.streamlit.io/en/stable/)

- Getting Started with MySQL in Python :: [https://www.datacamp.com/community/tutorials/mysql-python](https://www.datacamp.com/community/tutorials/mysql-python)

