#!/usr/bin/python
# -*- coding: utf-8 -*-


"""
[path]
cd  /Users/brunoflaven/Documents/01_work/blog_articles/script_in_script/

[file]
python launcher_2.py
python launcher_2.py tom bruno don marcel

"""


import myscriptC  # or from myscriptA import displayGUI
myscriptC.printOutNames()
