#!/usr/bin/python
# -*- coding: utf-8 -*-


"""
[path]
cd  /Users/brunoflaven/Documents/01_work/blog_articles/script_in_script/


[file]
python myscriptA.py

"""


def displayGUI():
    print("\n\n--- result")
    print ("I am from myscriptA.py in function displayGUI")
    print("\n")
    return


# displayGUI()
