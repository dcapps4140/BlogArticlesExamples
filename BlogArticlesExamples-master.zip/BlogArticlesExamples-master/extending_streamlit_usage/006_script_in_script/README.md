## 006_script_in_script

A modest start with some Streamlit basic diversion examples. The POC is there, it remains to sophisticated the usecases. In practic, the objective should be to quickly design a web interface on the tasks management scripts to ease handling, execution and automation. A kind of Capistrano or Jenkins imitation for Newbies.



## SOURCE
- Argument Parsing in Python :: [https://www.datacamp.com/community/tutorials/argument-parsing-in-python](https://www.datacamp.com/community/tutorials/argument-parsing-in-python)

-  How to Execute a Python File with Arguments in Python? :: [https://blog.finxter.com/how-to-execute-a-python-file-with-arguments-in-python/](https://blog.finxter.com/how-to-execute-a-python-file-with-arguments-in-python/)

- 10 tips for passing arguments to Python script :: [https://www.codeforests.com/2020/10/18/passing-arguments-to-python-script/](https://www.codeforests.com/2020/10/18/passing-arguments-to-python-script/)