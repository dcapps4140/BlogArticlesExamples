#!/usr/bin/python
# -*- coding: utf-8 -*-


"""
[path]
cd  /Users/brunoflaven/Documents/01_work/blog_articles/script_in_script/

[file]
python launcher_3.py
python launcher_3.py tom bruno don marcel

"""


import myscriptD  # or from myscriptA import displayGUI
myscriptD.printOutNames()
