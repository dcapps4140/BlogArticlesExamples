## 008_simple_app_spacy_example

Some examples with Spacy only.

## SOURCE

- Streamlit  :: [https://streamlit.io/](https://streamlit.io/)

- Streamlit Gallery :: [https://streamlit.io/gallery](https://streamlit.io/gallery)

- Streamlit Docs :: [https://docs.streamlit.io/en/stable/](https://docs.streamlit.io/en/stable/)

- JCharis Jesse on Github :: [https://github.com/Jcharis/](https://github.com/Jcharis/)

- spacy-streamlit: spaCy building blocks for Streamlit apps :: [https://github.com/explosion/spacy-streamlit](https://github.com/explosion/spacy-streamlit)
