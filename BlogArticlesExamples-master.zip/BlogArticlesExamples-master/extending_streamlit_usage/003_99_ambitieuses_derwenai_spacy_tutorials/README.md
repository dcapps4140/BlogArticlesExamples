## 003_99_ambitieuses_derwenai_spacy_tutorials

This quick POC was made for theater play made by in a 99 projects about Women Ambition with the help of Spacy, Pandas... a real case. <i>I have replaced the real text with article from by blog du the fact that the text was not officially released.</i>

The cases are in a Jupypter Notebooks.

**99 PROJECTS is a documentary and collaborative storytelling project to engage groups in a transformative journey**



## SOURCE
- 99 AMBITIONS, An experiment :: [http://www.the99project.net/2021/05/27/99-news-may-2021/](http://www.the99project.net/2021/05/27/99-news-may-2021/)
