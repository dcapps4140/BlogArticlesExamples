## 005_other_nlp_attempts

An advanced NLP text classification that require a lot of install. Caution, if you do not have the correct environment it won’t work properly, it will not work especially gensim library corpus for instance e.g. glove-wiki-gigaword-50.gz


## Source
- Text Analysis & Feature Engineering with NLP :: [https://towardsdatascience.com/text-analysis-feature-engineering-with-nlp-502d6ea9225d](https://towardsdatascience.com/text-analysis-feature-engineering-with-nlp-502d6ea9225d)


- Text Classification With NLP: Tf-Idf vs Word2Vec vs BERT :: [https://www.experfy.com/blog/ai-ml/text-classification-with-nlp-tf-idf-vs-word2vec-vs-bert/](https://www.experfy.com/blog/ai-ml/text-classification-with-nlp-tf-idf-vs-word2vec-vs-bert/)



