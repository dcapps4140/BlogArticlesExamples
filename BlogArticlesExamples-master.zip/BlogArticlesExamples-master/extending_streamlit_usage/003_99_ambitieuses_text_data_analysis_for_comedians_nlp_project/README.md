## 003_99_ambitieuses_text_data_analysis_for_comedians_nlp_project

An exploration of this project that gives a lot of insights on how to cleanup text to load in a pandas dataframe.


## Source
- Text Data Analysis for CoMeDiAnS- NLP Project :: [https://github.com/NishthaChaudhary/Text-Data-Analysis-for-CoMeDiAnS--NLP-Project](https://github.com/NishthaChaudhary/Text-Data-Analysis-for-CoMeDiAnS--NLP-Project)

