
# Create a POC with Kramer
=============================================

A very simple karmer file made in JavaScript



## Installation
---------------------
Require or look more in http://projects.framerjs.com/ 



## Usage
--------------
To help you to see the example, put in it on a server

## For more information
------------------------------------
Feel free to check in French some articles @
[Flaven.net](http://flaven.fr//)







