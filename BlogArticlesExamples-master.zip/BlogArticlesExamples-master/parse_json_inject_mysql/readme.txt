=== Migrating data from one API to another ===

== Installation ==

Just required MAMP installed and PHP-CLI accessible via the console.

- mojoinc_backup_all.sql: a quick scheme of the database that will receive the output of the JSON files.
- parse_and_insert.php: the script that enable the insert into the DB from the JSON files.
- lauch_sh_insert.sh: the bash script and the php file that help to generate it: launch_phpcli_parse_and_insert.php
- dump_generated_1.json, dump_generated_2.json, dump_generated_3.json: some JSON with fake data generated with json-generator.com

== Description ==

Check the article on flaven.fr

== Screenshots ==

No way

== Frequently Asked Questions ==

For some explanations see the website at flaven.fr

== Changelog ==

= 1.0 =
* Initial release.
