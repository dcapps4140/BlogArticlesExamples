=== Manage JSON-LD Settings for Wordpress ===

== Installation ==

1. Upload the `/json_ld` folder to your `/wp-content/plugins/` directory.
2. Activate the plugin through the `Plugins` menu in WordPress®.

== Description ==

If you want to implement some JSON-LD in your Wordpress, here is a very simple plugin to manage additional values for the JSON-LD that can be shown on all type of content element (homepage, post, page, author page...etc).

Thanks to this article :  https://builtvisible.com/implementing-json-ld-wordpress/ 

== Screenshots ==

No way

== Frequently Asked Questions ==

For some explanations see the website at flaven.fr

== Changelog ==

= 1.0 =
* Initial release.
