#!/usr/bin/python
# -*- coding: utf-8 -*-


"""
[path]
cd /Users/brunoflaven/Documents/01_work/blog_articles/build_interactive_webapps_python_scripts_using_streamlit/02_interactive_webapps_streamlit/


[file]
streamlit run 003c_interactive_webapps_streamlit_pandas.py




# more on infos and apps on
https://streamlit.io/
https://streamlit.io/gallery
https://docs.streamlit.io/en/stable/


"""

# Source :: ! ARTICLE_1 How to write Web apps using simple Python for Data Scientists? Check https: // mlwhiz.com/blog/2019/12/07/streamlit/



import streamlit as st
import pandas as pd
import numpy as np


# df = pd.read_csv("football_data_4.csv")
df_en = pd.read_csv("data/world_en.csv")
df_es = pd.read_csv("data/world_es.csv")


# id,name,alpha2,alpha3
option_en = st.selectbox(
    'Which Country do you like best?',
    df_en['name'].unique())

st.write('You selected:', option_en)

option_es = st.selectbox(
    '¿Qué país te gusta más?',
    df_es['name'].unique())

st.write('Seleccionaste:', option_es)

