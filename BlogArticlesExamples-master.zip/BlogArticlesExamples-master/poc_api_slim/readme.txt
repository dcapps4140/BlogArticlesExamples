=== Proof of concept to create a small Rest API with Slim, the minimalist PHP framework ===

== Installation ==


Coming...

== Screenshots ==

No way

== Frequently Asked Questions ==

For some explanations see the website at flaven.fr

== Changelog ==

= 1.0 =
* Initial release.


