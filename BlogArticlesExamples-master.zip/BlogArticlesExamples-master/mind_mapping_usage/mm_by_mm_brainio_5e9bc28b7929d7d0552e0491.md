# Qu'est-ce que le MindMapping ?
## THÉORIE
### Double Objectif
#### S'améliorer
##### Capacités
* Expliquer
##### Efficacité
* Apprendre
#### Simultané
##### Faire
* Action
* Mouvement
##### Penser
* Visuel
* Image
### Cerveau
#### Aider
* Libre
* Personel
#### Jouer
* Imagination
* Association
## PRATIQUE
### Comment ?
#### Feuille Blanche
Horizontale
##### Sujet
Centre
##### Mots-Clés
Rayon
##### Connections
Branches
### Pourquoi ?
#### "Couteau Suisse"
Récupération
Situations
Explications
