# Qu'est-ce qu'une pomme ?
## Fruit
*Sucre
*Confiture
## Pommier
*Campagne
*Normandie
*Vert
## Conte
### Graine
*Géant
*Haricot
### Blanche-neige
*Rouge
*Poison
*Psy
*Merveilleux

