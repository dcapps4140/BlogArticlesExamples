
# The Trump Team
=============================================
A graphical representation of the Trump Team based on an example at the origin made for the Marvel Superhero.
Most of the data come from 2 articles one in English, the other in French.

[d3 | Force layout with images](http://bl.ocks.org/eesur/be2abfb3155a38be4de4)


[Donald Trump's Cabinet-in-waiting: What we know so far](http://www.politico.com/blogs/donald-trump-administration/2016/11/donald-trump-cabinet-members-list-of-choices-picks-and-selections-so-far-231444)


[L'équipe Trump](http://www.liberation.fr/apps/2016/12/equipe-trump/)


## Installation
---------------------
You need to have a local or a remote web server to see the file working


## Usage
--------------
Just for fun


## For more information
------------------------------------
Feel free to check in French some articles @
[Flaven.net](http://flaven.fr//)








