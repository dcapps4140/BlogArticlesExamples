
# Create a web extension for chrome
=============================================


## Installation
---------------------
Check the article to load the extension inside Chrome


## Usage
--------------
The idea was to explore quickly the way to create an web extension for the chrome browser.


## For more information
------------------------------------
Feel free to check in French some articles @
[Flaven.net](http://flaven.fr//)








