
# Deeplinks, iOS, Android, QR code - Operational testing on Universal Links Deeplinks in Android or iOS applications with QR code
=============================================


## Usage
--------------
I made recently a small introduction on how to implement the Universal Links Deeplinks in a mobile application both for Android or iOS. I told at the time that the operational acceptance testing implementation was pretty tedious both in iOS or Android. Using QR code is very practical and speed up the operational acceptance testing process of your applications in iOS and Android.


## For more information
------------------------------------
Feel free to check in English some articles @
[Deeplinks, iOS, Android, QR code – Operational testing on Universal Links Deeplinks in Android or iOS applications with QR code](http://flaven.fr/2019/01/deeplinks-ios-android-qr-code-operational-testing-on-universal-links-deeplinks-in-android-or-ios-applications-with-qr-code/)








