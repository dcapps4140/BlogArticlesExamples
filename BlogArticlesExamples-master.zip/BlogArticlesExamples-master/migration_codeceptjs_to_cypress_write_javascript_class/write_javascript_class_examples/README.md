# write_javascript_class_examples

Some examples to decompose and learn how to write a Class in Javascript. These examples have been made to prepare a migration from CodeceptJS to Cypress, making the best of the 2 UAT testing frameworks for an webapplication.

Read more in the post: [Prepare a migration from CodeceptJS to Cypress, making the best of the 2 UAT testing frameworks for an webapplication](https://flaven.fr/2022/05/prepare-a-migration-from-codeceptjs-to-cypress-making-the-best-of-the-2-uat-testing-frameworks-for-an-webapplication/)

```bash

# The idea is to load the html files inside the browser e.g. Chrome
cd /Users/brunoflaven/Documents/03_git/BlogArticlesExamples/migration_codeceptjs_to_cypress_write_javascript_class/write_javascript_class_examples/

```

