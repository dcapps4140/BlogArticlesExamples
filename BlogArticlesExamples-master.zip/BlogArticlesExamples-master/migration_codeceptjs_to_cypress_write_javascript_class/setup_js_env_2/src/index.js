function greet(guestName) {
    console.log(`Hello ${guestName}!`);
}

function showName(name) {
    // console.log(`My name is  ${name}...`);
    console.log('My name is '+name+'... ');
}


console.log("[INFO] Script loaded...")

greet('Guest');
showName('Bruno');